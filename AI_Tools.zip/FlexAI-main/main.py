import json
import os

from openai import OpenAI
from dotenv import load_dotenv

from tools import TOOLS, TOOL_DEFINITIONS


load_dotenv()

client = OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key=os.getenv("OPENROUTER_API_KEY")
)
'''
Perticular tool used 
'''
def run_tool(tool_name, arguments):
    if tool_name not in TOOLS:
        raise ValueError(f"Unknown tool: {tool_name}")
    tool = TOOLS[tool_name]
    return tool(**arguments)
'''
AI
'''
def ask_ai(user_message):
    conversation = [
        {
            "role": "user",
            "content": user_message
        }
    ]
    while True:
        response = client.responses.create(
            model="openrouter/free",
            input=conversation,
            tools=TOOL_DEFINITIONS,
            tool_choice="auto"
        )
        tool_calls = [
            item
            for item in response.output
            if item.type == "function_call"
        ]
        if not tool_calls:
            return response.output_text
        conversation.extend(response.output)
        for call in tool_calls:
            arguments = json.loads(call.arguments)
            result = run_tool(
                call.name,
                arguments
            )
            conversation.append(
                {
                    "type": "function_call_output",
                    "call_id": call.call_id,
                    "output": str(result)
                }
            )
'''
Loop of the continous chat by the user and AI
(quit by typing quit or exit)
'''
while True:
    user_message = input("\nYou: ")
    if user_message.lower() in ["exit", "quit"]:
        break
    answer = ask_ai(user_message)
    print("FlexAI: ", answer)