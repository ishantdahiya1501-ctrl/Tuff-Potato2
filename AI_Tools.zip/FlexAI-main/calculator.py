import ast
import operator

'''
For now there are some basic set of operations which can be performed by the Model this
calculator inclued all the operations given below
'''
OPERATORS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Pow: operator.pow,
    ast.Mod: operator.mod,
}


def calculate(expression):
    tree = ast.parse(expression, mode="eval")

    def evaluate(node):

        if isinstance(node, ast.Expression):
            return evaluate(node.body)

        if isinstance(node, ast.Constant):
            if isinstance(node.value, (int, float)):
                return node.value

            raise ValueError("FlexAI: Only numbers are allowed.")

        if isinstance(node, ast.BinOp):
            left = evaluate(node.left)
            right = evaluate(node.right)

            operation = OPERATORS.get(type(node.op))

            if operation is None:
                raise ValueError("FlexAI: Operation not supported")

            return operation(left, right)

        if isinstance(node, ast.UnaryOp):

            value = evaluate(node.operand)

            if isinstance(node.op, ast.USub):
                return -value

            if isinstance(node.op, ast.UAdd):
                return value

            raise ValueError("FlexAI do not support Unary operators.")

        raise ValueError("FlexAI: Invalid expression")

    return evaluate(tree)

'''
if __name__ == "__main__":
    print(calculate("4 + 2"))
    print(calculate("4 - 2"))
    print(calculate("4 / 2"))
    print(calculate("4 * 2"))
    print("all calculations are performed succesfully\nprogram is running without any error")


Dont remove the comments and if are removing so plz also remove this set of code so that it
dont intrupt btween the processing of multiple tools
'''