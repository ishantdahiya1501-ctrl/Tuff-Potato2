FRIES — Development Roadmap

Phase 1 — Core Multimodal AI

Fries is a multimodal AI system composed of specialized small models, such as Tuff Potato, Tuff Potato Maths, and others.

What makes it different:

5.6M parameters total
Each model works independently
Designed to run on embedded hardware with 10+ MB PSRAM
Target boards: ESP32-S3, ESP32-P4, ESP32-C5, ESP32-C6
Focus on human-like basic conversation at an extremely small model scale
Phase 2 — Give Fries a Body
1. Presence & Body
Desk companion or two-legged waddling robot
Screen-based eyes
Blinking, looking around, and mood animations
Head pan/tilt follows your face
Wakes when you sit down using PIR/mmWave
Sleeps/dozes when ignored
Reacts to touch: pet, poke, hold
Edge detection to prevent falling from the desk
Idle behaviors:
Looks around
Stretches
Slow blinking
Sighs
2. Voice
Wake-word detection: “hey bot”
Short speech recognition for 5–10-word commands
Text-to-speech responses
Robotic but clear voice
Simple lowercase English responses
Restricts responses outside its supported language
3. Conversation
Basic English small talk
Greetings
Name
Feelings
Likes
Weather
Day/time
Goodbyes
Remembers user's name and a few facts
Remembers yesterday's mood or previous topic
Says “i do not know” instead of guessing
Refuses unsupported topics such as advanced math and coding
Consistent personality and tone
4. Emotion & Personality
Mood states:
Happy
Sleepy
Curious
Bored
Excited
Mood changes:
Facial animations
Voice tone
Response style
Gets excited when praised
Becomes quieter when shouted at
Reacts when picked up or moved
Develops more animated reactions when the user returns
5. Math Engine

A symbolic engine, not an LLM.

Addition
Subtraction
Multiplication
Division
Percentages
Basic unit conversion
Timer calculations
Deterministic results
No mathematical hallucinations
6. Timers & Reminders
Set timers
Set reminders
Alarm/wake-up commands
Pomodoro mode
Focus/break states
Persistent storage across reboots using SD
7. Home Control

Using IR, ESP-NOW, and relay nodes:

AC control
TV control
Lights
Fans
Smart plugs
Volume/input control
Temperature control
Light dimming

Routines:

Good night → lights off, AC on, door locked, sleep sounds
I'm leaving → everything off
Movie time → lights dim, TV on
Focus mode → warm lights, notifications muted

Presence automation:

User leaves → turn off lights and AC
User arrives → greeting + lights on
8. Arm — 2–3 DOF
Wave hello/goodbye
Point at objects
Point at people
Nod/shake head
Reach for small objects
Pick up lightweight objects
Hand objects to the user
Push/tap objects
Learn and replay taught poses
Synchronize gestures with speech

Example:

“i am happy” → arms go up + happy expression

9. Vision — On-Device Computer Vision

Using classical CV rather than a large vision model:

Face detection
Face tracking
Head-following
Motion detection
Room presence detection
Color tracking
Red-ball tracking
Line following
Desk-edge detection
QR-code scanning
Barcode scanning
Final Goal

Phase 1:
Fries = tiny multimodal AI

Phase 2:
Fries + body + voice + vision + emotions + memory + robotics + home control

→ A complete autonomous desktop AI companion.
