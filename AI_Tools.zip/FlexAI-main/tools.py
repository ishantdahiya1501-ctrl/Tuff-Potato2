from calculator import calculate
from weather import get_weather
from unit_converter import unit_converter
from currency_converter import currency_converter
'''
Tools used by the AI model to give answers
'''
TOOLS = {
    "calculator": calculate,
    "get_weather": get_weather,
    "unit_converter": unit_converter,
    "currency_converter": currency_converter
}


TOOL_DEFINITIONS = [

    # ========================================================
    # CALCULATOR
    # ========================================================

    {
        "type": "function",
        "name": "calculator",
        "description": "Calculate a mathematical expression.",
        "parameters": {
            "type": "object",
            "properties": {
                "expression": {
                    "type": "string",
                    "description": "A mathematical expression such as 25 * 17"
                }
            },
            "required": ["expression"],
            "additionalProperties": False
        }
    },

    {
        "type": "function",
        "name": "get_weather",
        "description": "Get the current weather information for a city.",
        "parameters": {
            "type": "object",
            "properties": {
                "city": {
                    "type": "string",
                    "description": "The name of the city to get weather for."
                }
            },
            "required": ["city"],
            "additionalProperties": False
        }
    },

    {
        "type": "function",
        "name": "unit_converter",
        "description": "Convert a value from one unit to another. Supports length, mass, temperature, speed, and time.",
        "parameters": {
            "type": "object",
            "properties": {
                "value": {
                    "type": "number",
                    "description": "The numerical value to convert."
                },
                "from_unit": {
                    "type": "string",
                    "description": "The unit the value is currently in, such as km, meter, kg, celsius, mph, or hour."
                },
                "to_unit": {
                    "type": "string",
                    "description": "The unit to convert the value into, such as meter, km, pound, fahrenheit, km/h, or minute."
                }
            },
            "required": [
                "value",
                "from_unit",
                "to_unit"
            ],
            "additionalProperties": False
        }
    },

    {
        "type": "function",
        "name": "currency_converter",
        "description": "Convert an amount from one currency to another using current exchange rates.",
        "parameters": {
            "type": "object",
            "properties": {
                "amount": {
                    "type": "number",
                    "description": "The amount of money to convert."
                },
                "from_currency": {
                    "type": "string",
                    "description": "The three-letter currency code to convert from, such as USD, INR, EUR, or GBP."
                },
                "to_currency": {
                    "type": "string",
                    "description": "The three-letter currency code to convert to, such as USD, INR, EUR, or GBP."
                }
            },
            "required": [
                "amount",
                "from_currency",
                "to_currency"
            ],
            "additionalProperties": False
        }
    }

]